# executando espeak por comando python
import os

os.system('espeak -v pt-br "Olá mundo"')